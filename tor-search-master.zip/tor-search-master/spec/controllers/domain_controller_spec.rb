# encoding: utf-8

require 'spec_helper'

describe DomainController do

  it 'ads a domain' do
    pending
  end

  it 'doesn\'t add an invalid domain' do
    pending
  end

end
