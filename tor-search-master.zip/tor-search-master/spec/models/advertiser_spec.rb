# encoding: utf-8

require 'spec_helper'

describe Advertiser do

  fixtures :advertisers

  it 'can login with a username'

end
