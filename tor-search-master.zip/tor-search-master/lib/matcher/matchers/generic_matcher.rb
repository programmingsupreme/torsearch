# encoding: utf-8

# generic matcher initializes the matcher

class GenericMatcher
  def initialize(request, term)
    @request = request
    @term = term
  end
end
