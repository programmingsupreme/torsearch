module TrendingHelper
end
